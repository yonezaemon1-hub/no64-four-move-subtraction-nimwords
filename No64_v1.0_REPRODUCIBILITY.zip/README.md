# No.64 v1.0 — reproducibility package

Complete Nim-Words and Sharp Preperiods for the Four-Move Subtraction Family {5,11,15,c}
Ryutaro Yonezu — Independent Researcher. Published 11 November 2026.

Use Python 3.10 or later, standard library only, in a writable extracted directory:

    python -B verify_no64.py

Optional independent C++17 recurrence check:

    g++ -std=c++17 -O2 -Wall -Wextra -Werror verify_no64_independent.cpp -o verify_no64_independent
    ./verify_no64_independent

On Windows PowerShell 5.1, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\run_windows.ps1` from the extracted directory. The runner and two verifier sources are byte-identical to the canonical v0.1 archive. Their historical candidate/HOLD labels describe the original packaging date and do not override the current publication status. The runner performs local checks only. Python rewrites the two CSVs deterministically, using the same frozen bytes on Linux and Windows.

`PROOF_CANDIDATE.md` retains the historical filename referenced by the frozen programs; its mathematical core is unchanged and its publication metadata is current. The typeset v1.0 PDF and TeX accompany this ZIP as separate public assets.

The analytical infinite-family proof applies to odd c>=59 with least T=c+29 and p=2. The 21 odd c=17..57 are handled by finite recurrence certificates. A wider all-odd-a formula is an unproved computational conjecture. This package does not establish it.

Read VERIFICATION.md for source hashes, scope and review provenance, and PROOF_CANDIDATE.md for known prior results and unresolved literature coverage. Ho's base triple and Zhang's finite observations are known. Flammenkamp's expanded 1997 book is unchecked. Moriwaki Theorems 2/4 were ruled out only as direct applications under the compared conditions.

External AI audit: reviewer-reported PASS within scope. Windows: author-run PASS on frozen v0.1, not independently witnessed. Human peer review and formal proof-assistant verification: not performed. NOVELTY INCONCLUSIVE. REFERENCES PARTIAL. All rights reserved.

`SHA256SUMS.txt` covers all package files except itself. The original audit archives, historical draft PDFs, personal/raw Windows logs and third-party full texts are excluded.
