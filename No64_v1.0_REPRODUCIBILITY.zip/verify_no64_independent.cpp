// Independent C++17 finite recurrence audit, without Python imports or file IO.
// Evidence for finite computations only. Infinite proof: PROOF_CANDIDATE.md.
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <stdexcept>
using namespace std;

vector<int> compute(int c,int N) {
  vector<int> out(N+1,0);
  const int moves[4]={5,11,15,c};
  for (int n=0;n<=N;++n) {
    unsigned mask=0;
    for (int s:moves) if(n>=s) mask |= 1u<<out[n-s];
    int k=0;while(mask&(1u<<k))++k;
    out[n]=k;
  }
  return out;
}

int main() {
  const map<int,pair<int,int>> small={
    {17,{46,2}},{19,{52,2}},{21,{0,26}},{23,{58,2}},
    {25,{54,2}},{27,{56,2}},{29,{36,20}},{31,{80,2}},
    {33,{62,2}},{35,{64,2}},{37,{66,2}},{39,{68,2}},
    {41,{96,2}},{43,{98,2}},{45,{74,2}},{47,{76,2}},
    {49,{78,2}},{51,{80,2}},{53,{82,2}},{55,{84,2}},
    {57,{86,2}}};
  const string B="00000111110222213333020001011101022101330102";
  const string D="12121030301010101010101210103";
  if(B.size()!=44||D.size()!=29) return 1;
  for(int c=17;c<=2001;c+=2) {
    int T=(c>=59 ? c+29 : small.at(c).first);
    int p=(c>=59 ? 2 : small.at(c).second);
    int N=T+2*p+2*c+40;
    auto g=compute(c,N);
    for(int n=T;n+p<=N;++n)
      if(g[n]!=g[n+p]) {cerr<<"FAIL periodic c="<<c<<" n="<<n<<"\n";return 2;}
    if(T>0 && g[T-1]==g[T-1+p]) {cerr<<"FAIL sharp T c="<<c<<"\n";return 3;}
    for(int d=1;d<p;++d) if(p%d==0) {
      bool lower=true;
      for(int j=0;j<p-d;++j)if(g[T+j]!=g[T+j+d]){lower=false;break;}
      if(lower){cerr<<"FAIL primitive period c="<<c<<"\n";return 4;}
    }
    if(c>=59) {
      for(int n=0;n<=N;++n) {
        int v=(n<44?B[n]-'0':n<c?n%2:n<c+29?D[n-c]-'0':n%2);
        if(g[n]!=v){cerr<<"FAIL closed word c="<<c<<" n="<<n<<"\n";return 5;}
      }
    }
  }
  cout<<"PASS: C++17 independent recurrence, sharp T and p, every odd c=17..2001 (993 cases)\n";
  cout<<"PASS: closed nim-word at every odd c=59..2001 (972 cases)\n";
  return 0;
}
