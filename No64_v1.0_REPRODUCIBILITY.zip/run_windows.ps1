# No.64 candidate — Windows PowerShell 5.1 reproduction runner.
# Run in the extracted package folder; it performs no network or publication action.
$ErrorActionPreference = 'Stop'
$work = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $work
try {
    $py = Get-Command python -ErrorAction Stop
    Write-Host 'No64 Python finite proof certificate check:'
    & $py.Source -B (Join-Path $work 'verify_no64.py')
    if ($LASTEXITCODE -ne 0) { throw 'Python verification FAILED' }
    $cpp = Get-Command g++ -ErrorAction SilentlyContinue
    if ($null -ne $cpp) {
        Write-Host 'No64 independent C++17 cross-check:'
        $exe = Join-Path $env:TEMP 'no64_independent_verify.exe'
        & $cpp.Source -std=c++17 -O2 -Wall -Wextra -Werror (Join-Path $work 'verify_no64_independent.cpp') -o $exe
        if ($LASTEXITCODE -ne 0) { throw 'C++ build FAILED' }
        & $exe
        if ($LASTEXITCODE -ne 0) { throw 'C++ verification FAILED' }
        Remove-Item $exe -Force -ErrorAction SilentlyContinue
    } else {
        Write-Host 'C++ SKIP: g++ not found; Python check still PASS.'
    }
    Write-Host 'No64 reproduction completed. NOVELTY INCONCLUSIVE; PUBLICATION HOLD.'
} finally {
    Pop-Location
}
