#!/usr/bin/env python3
"""No.64 v0.1 independently runnable, stdlib-only finite certificates.
The analytic all-c proof is in PROOF_CANDIDATE.md; this program does NOT
turn finitely many c-values into a proof of the infinite family.
"""
import csv
from pathlib import Path

B = '00000111110222213333020001011101022101330102'  # 44 digits
D = '12121030301010101010101210103'  # 29 digits
SMALL = {
    17:(46,2), 19:(52,2), 21:(0,26), 23:(58,2),
    25:(54,2), 27:(56,2), 29:(36,20), 31:(80,2),
    33:(62,2), 35:(64,2), 37:(66,2), 39:(68,2),
    41:(96,2), 43:(98,2), 45:(74,2), 47:(76,2),
    49:(78,2), 51:(80,2), 53:(82,2), 55:(84,2), 57:(86,2),
}

def mex(vals):
    z=set(vals); m=0
    while m in z: m+=1
    return m

def recurrence(moves, max_n):
    out=[]
    for n in range(max_n+1):
        out.append(mex(out[n-s] for s in moves if n>=s))
    return out

def candidate(c,n):
    if n<44: return int(B[n])
    if n<c: return n%2
    if n<c+29: return int(D[n-c])
    return n%2

def check_base():
    assert len(B)==44 and len(D)==29
    # finite word lemma: T=44,p=2,max move 15; check up to T+p+15-1=60.
    g=recurrence((5,11,15),60)
    assert all(g[n] == (int(B[n]) if n<44 else n%2) for n in range(61))
    assert all(int(B[j]) != 0 for j in range(29,44,2))
    assert all(int(B[j]) != 1 for j in range(30,44,2))
    print('PASS: 3-move base word; 61 finite recurrence positions')

def check_symbolic_large():
    # In i=0..28, the three small predecessors are either in the known
    # alternating base (if i<s) or in the earlier part of D (if i>=s).
    # The c-predecessor is always B_i. This symbolic calculation is c-free.
    cert=[]
    for i in range(29):
        values=[(i%2) if i<s else int(D[i-s]) for s in (5,11,15)]
        values.append(int(B[i]))
        assert mex(values)==int(D[i]), (i,values,D[i])
        cert.append(dict(offset_i=i,move_5=values[0],move_11=values[1],
                         move_15=values[2],move_c=values[3],mex=int(D[i])))
    pth=Path(__file__).parent/'PATCH_29_MEX_TABLE.csv'
    with pth.open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=cert[0].keys());w.writeheader();w.writerows(cert)
    # All odd indices >=29 have nonzero candidates (base, patch, alternating).
    assert all(int(D[i])!=0 for i in range(0,29,2))
    # All even indices >=30 have candidate other than one.
    assert all(int(D[i])!=1 for i in range(1,29,2))
    assert D[25]=='0' and D[27]=='0' and D[28]=='3'
    print('PASS: all 29 symbolic D mex checks; parity invariants; sharp boundary')

def check_small():
    rows=[]
    for c,(T,p) in SMALL.items():
        # The periodic-word lemma: check recurrence by direct enumeration
        # through index T+p+c-1, and compare two adjacent length-c windows.
        end=T+p+c-1
        g=recurrence((5,11,15,c),end)
        assert all(g[n]==g[n+p] for n in range(T,T+c)), (c,T,p)
        # The tail word has primitive period p iff no proper divisor works.
        divisors=[d for d in range(1,p) if p%d==0]
        assert all(any(g[T+j]!=g[T+j+d] for j in range(p-d)) for d in divisors),c
        # No period of the primitive tail can begin at T-1 or earlier.
        if T:
            assert g[T-1]!=g[T-1+p],c
        rows.append(dict(c=c,preperiod=T,period=p,
                         last_checked=end,
                         preceding_value=g[T-1] if T else '',
                         periodic_successor=g[T-1+p] if T else '',
                         prefix_word=''.join(map(str,g[:T])),
                         period_word=''.join(map(str,g[T:T+p]))))
    pth=Path(__file__).parent/'SMALL_FINITE_CERTIFICATES.csv'
    with pth.open('w',newline='',encoding='utf-8') as fh:
        writer=csv.DictWriter(fh,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    print(f'PASS: all {len(rows)} small odd-c finite proof certificates, sharp T and p')

def check_large_examples():
    count=0
    for c in range(59,2002,2):
        end=2*c+100
        g=recurrence((5,11,15,c),end)
        for n in range(end+1):
            assert g[n] == candidate(c,n), (c,n,g[n],candidate(c,n))
        count+=1
    print(f'PASS: direct recurrence vs closed word for {count} odd c = 59..2001')

def check_general_pattern_exploratory():
    # For the *unproved* all-a conjecture; not a theorem certificate.
    for a in range(3,28,2):
        c=2*a*a+3*a+3
        if c%2==0: c+=1
        g=recurrence((a,2*a+1,3*a,c),c+4*a*a+100)
        delta=2*a*a-4*a-1
        T=c+delta
        assert all(g[n]==n%2 for n in range(T,len(g)))
        assert g[T-1]!=g[T-1+2]
    print('OBSERVATION ONLY: quadratic preperiod formula sampled at a=3,5,...,27')

if __name__=='__main__':
    check_base();check_symbolic_large();check_small();check_large_examples();check_general_pattern_exploratory()
    print('PASS: No.64 v0.1 Python verifier completed; infinite proof is separate')
