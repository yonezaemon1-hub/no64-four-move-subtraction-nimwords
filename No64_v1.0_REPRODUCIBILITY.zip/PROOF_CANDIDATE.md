# Research No.64 — v1.0 mathematical preprint

**Title:** Complete Nim-Words and Sharp Preperiods for the Four-Move Subtraction Family {5,11,15,c}

**Status:** Mathematical proof and independent recurrence computations **PASS as reported by a separate AI reviewer**; author-run Windows PowerShell 5.1 **PASS** (not independently witnessed). **REFERENCES PARTIAL / NOVELTY INCONCLUSIVE / Published v1.0, 11 November 2026**. No human peer review or formal proof verification. The proof following this paragraph is byte-for-byte unchanged from v0.1.

## Definitions

For a one-pile normal-play subtraction game with finite move set S, let g_S(0)=0 and

    g_S(n) = mex { g_S(n-s) : s in S, s <= n }, n >= 0.

The least eventual period p is the smallest positive integer for which there exists T with g(n+p)=g(n) for all n>=T. The least preperiod T is the earliest such index (equivalently the earliest beginning of any periodic suffix).

Write B and D for the following digit words (digits are nim-values, not decimal numbers):

    B = 00000111110222213333020001011101022101330102       (44 letters)
    D = 12121030301010101010101210103                      (29 letters)

## Theorem

For every odd c>15, set S_c={5,11,15,c}.

(i) If c>=59, the **complete infinite word** is

    g_c = B (01)^((c-45)/2) 0 D (01)^infinity.

Its **least** preperiod and least eventual period are

    T_c = c+29,    p_c = 2.

(ii) For 17<=c<=57 odd, the pairs (T_c,p_c) are

| c | T | p | c | T | p | c | T | p |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|17|46|2|19|52|2|21|0|26|
|23|58|2|25|54|2|27|56|2|
|29|36|20|31|80|2|33|62|2|
|35|64|2|37|66|2|39|68|2|
|41|96|2|43|98|2|45|74|2|
|47|76|2|49|78|2|51|80|2|
|53|82|2|55|84|2|57|86|2|

For every one of these finite cases, the exact finite prefix and the primitive periodic word are reproducibly obtained in `SMALL_FINITE_CERTIFICATES.csv`. The finite recurrence verification plus the following lemma proves the stated infinite periodic tails; the primitive-word test and left-boundary mismatch establish minimality.

## Lemma A — finite recurrence check for a proposed periodic word

Let c=max(S). Suppose a candidate infinite word f is periodic from T with period p. If its mex recurrence is correct at all n in [0,T+p+c-1], then it is correct at all n. For n>=T+p+c, all terms (n-p)-s in the recurrence lie at or beyond T. Their f-values agree with those at n-s by the p-periodicity. By induction the mex at n equals the mex at n-p, which equals f(n-p)=f(n). QED.

## Lemma B — the base three-move sequence

For S_0={5,11,15}, the exact infinite nim-word is

    g_0 = B (01)^infinity

with the alternating suffix beginning at index 44. Verification of the mex recurrence at indices n=0,...,60 is an exact finite proof by Lemma A with T=44, p=2, c=15. The base prefix B has length 44. Moreover, for every odd j>=29, g_0(j)!=0; for every even j>=30, g_0(j)!=1. These are finite checks for 29<=j<=43 and immediate from the alternating suffix thereafter. In particular, g_0(j)=j mod 2 for every j>=44.

## Proof of the theorem for all odd c>=59

Define f by the displayed word in Theorem (i). We prove f satisfies the mex recurrence for each n by dividing the indices into three regimes.

**1. n<c.** The c-move is not available. By Lemma B, and since c>=59, f(n) agrees exactly with g_0(n), so the recurrence holds.

**2. c<=n<=c+28.** Write n=c+i for 0<=i<=28. Because c>=59 and is odd, for each s in {5,11,15}:

- If i<s, n-s belongs to the unperturbed alternating region [44,c-1], so f(n-s)=i mod 2 (both c and s are odd).
- If i>=s, n-s=c+(i-s) and f(n-s)=D_{i-s}, an earlier entry of the proposed patch.
- The fourth predecessor is n-c=i, with f(i)=B_i (since i<=28<44).

Thus for every i the *symbolic, c-independent* recursion is

    D_i = mex( { B_i } union { i mod 2 if i<s; D_(i-s) if i>=s : s=5,11,15 } ).

All 29 equalities are verified directly in `PATCH_29_MEX_TABLE.csv` by the Python verifier `verify_no64.py`. This is a finite arithmetic check independent of the value of c. Therefore the recursion holds for the whole 29-letter defect patch for every admissible c.

**3. n>=c+29.** From the explicit words B, D, and the alternating portions, we have two global parity exclusions:

    (A)  f(j) != 0 at every odd j>=29;
    (B)  f(j) != 1 at every even j>=30.

For (A), check the eight odd indices 29..43 in B, the odd global indices of D (even i), and the alternating regions. For (B), check the seven even indices 30..42 of B, the even global indices of D (odd i), and the alternating regions.

If n>=c+29 is even, all predecessor indices n-5,n-11,n-15,n-c are odd and at least 29, so (A) makes all their values nonzero. The mex is 0=f(n).

If n>=c+29 is odd, then n>=c+30; all predecessor indices are even and at least 30, so none has value 1 by (B). Furthermore n-5 is an even index >=c+25, and all even indices j>=c+25 have value 0: the patch entries D_25=D_27=0, and all later even indices are in the alternating suffix. Hence the predecessor values include 0 but not 1, so their mex is 1=f(n).

This completes the induction-free verification of the candidate recurrence and hence (by uniqueness of the mex recursion) the formula for every odd c>=59.

**Sharpness.** The periodic suffix begins at T=c+29, an even index, and has both 0 and 1: its primitive period is 2. The immediately preceding index c+28 contains D_28=3, while *every* term from T onward is 0 or 1. Any positive period q starting at an earlier index would require f(c+28)=f(c+28+q), which is impossible. Therefore T=c+29 is the least preperiod for any eventual period. QED.

## Proof for 17<=c<=57 odd

For each of the 21 values in the theorem, the Python verifier calculates g directly through N=T+p+c-1 and checks all comparisons g(n)=g(n+p) for T<=n<=T+c-1. By Lemma A, repeating the block g(T),...,g(T+p-1) yields a valid infinite recurrence solution, proving the asserted eventual period. The verifier then checks (a) no proper divisor of p is a period of its cyclic word; and (b) if T>0, g(T-1)!=g(T-1+p). For any primitive period p, all other periods of its infinite repetition are multiples of p. If an earlier periodic suffix existed with period kp, then at index T-1 it would force g(T-1)=g(T-1+kp)=g(T-1+p), contradicting (b). Therefore the reported p and T are both minimal. The table `SMALL_FINITE_CERTIFICATES.csv` records every exact check and primitive word. QED.

## Novelty and limitations

- **Known:** Ho (2015), Theorem 5, supplies the base triple {5,11,15} minimal preperiod 44 and period 2. The explicit B prefix and parity exclusions are independently verified in the proof, not claimed as a new triple-game result.
- **Known observations:** Zhang (2024), Remark 7, bounded four-move calculations include the period-2 pattern and exceptional c=21 (T=0,p=26) and c=29 (T=36,p=20). The cited observations are not claimed as new.
- **Original thesis checked:** Flammenkamp original dissertation (submitted 1996, often cited 1997), converted to 156 PDF pages; relevant general theorems and 59 numbered four-move families compared, no direct anticipation identified there.
- **Book unverified:** Flammenkamp expanded 1997 print edition ISBN 3-932136-10-1 unavailable; it is not covered by the dissertation comparison.
- **Moriwaki checked:** Moriwaki (2026), arXiv:2606.11658v1, Theorems 2/4 require all successive gaps <= the smallest move; 11-5=6>5, so no direct application to this four-move set. Starting Theorem 4 from a proper subset of the odd set would first adjoin an even number s_min+s_max, impossible within an all-odd target. This does not rule out other or indirect results.
- **Finite-table nuance:** T=c+29 also holds at odd 45<=c<=57, but the uniform closed nim-word theorem stays c>=59. Independent finite checking also agrees with that word at c=49; that is not a new infinite-family proof.
- **Wider conjecture:** The equation T=c+2a^2-4a-1 and period 2 for all sufficiently large odd c remains EXPERIMENTAL, not proved for general odd a.
- **Review provenance:** The external AI PASS report was supplied in chat by the user, and reviewer code/logs were not separately uploaded for this v0.2 packaging. The author's Windows PASS output was not independently witnessed.
- **Historical novelty:** INCONCLUSIVE. Human peer review: not done. Original v0.1 frozen files/code/CSV unchanged. Public release: Published v1.0, 11 November 2026. All rights reserved.

## Separate, unproved all-a conjecture

For odd a>=3 and all sufficiently large odd c>3a, numerical evidence suggests

    T({a,2a+1,3a,c}) = c + 2a^2 - 4a - 1,   p=2.

The computational experiments do not prove this wider statement.
